package com.example.modul3_nomer1

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnProfile = findViewById<Button>(R.id.btnprofile)
        btnProfile.setOnClickListener(View.OnClickListener { val intent = Intent(this, ProfileActivity::class.java)
        startActivity(intent)
        })

        val btnDialNumber: Button = findViewById(R.id.btndial)
        btnDialNumber.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when(v.id){
            R.id.btndial-> {
                val phoneNumber = "087850125552"
                val dialNumber = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialNumber)
            }
        }
    }
}